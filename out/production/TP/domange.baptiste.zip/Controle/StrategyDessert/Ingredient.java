package Controle.StrategyDessert;

/**
 * Created by baptiste on 15/06/17.
 */
public interface Ingredient {

    public double coutIngredient(double dessert);

}
