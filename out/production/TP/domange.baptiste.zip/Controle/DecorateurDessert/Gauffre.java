package Controle.DecorateurDessert;

/**
 * Created by baptiste on 15/06/17.
 */
public class Gauffre extends Dessert {

    Gauffre(){
        setPrix(1.8);
    }

}
