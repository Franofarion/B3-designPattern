package Controle.DecorateurDessert;

/**
 * Created by baptiste on 15/06/17.
 */
public class Crepe extends Dessert {

    Crepe(){
        setPrix(1.5);
    }

}
